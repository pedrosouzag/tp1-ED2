#ifndef TEMPO_H
#define TEMPO_H

double now_seconds(void);

#endif
