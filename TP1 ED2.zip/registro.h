#ifndef REGISTRO_H
#define REGISTRO_H

typedef struct{
    int chave;
    long int dado1;
    char dado2[5000];
}Registro;

#endif